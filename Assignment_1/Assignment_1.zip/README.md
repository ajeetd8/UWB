# Process, and threadOS

The prcess.cpp implement the ps -A | grep `command` | wc -l, with multi processing approach. With process.cpp you might be able to see how bash shell handles the multiple instruction with multiple processes.

The <strong>threadOS</strong> is the project to implement how does an operating system system implemented. The project is implemented based on Prof. Robert Dampsey's ThreadOS, and I've implemented <strong>Shell.java.</strong> 

## Getting Started

I 've provided multiple class files in ThreadOS, and everyting has been compiled already. In order to run process.cpp, you just need to compile, and run.

### Prerequisites

What things you need to install the software and how to install them

```
g++, java, Unix environment
```

### Installing

A step by step series of examples that tell you how to get a development env running

Compiling

```
g++ -o proc process.cpp
proc arguement

```


```
javac threadOS/Shell.java
java threadOS/Boot
```

End with an example of getting some data out of the system or using it for a little demo


## Deployment

This project is a part of course work.
 

## Authors
* **Haram Kown** - *Initial work*